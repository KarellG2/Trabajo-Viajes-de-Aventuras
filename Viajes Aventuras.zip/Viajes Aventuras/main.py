import customtkinter as ctk
from tkinter import messagebox   
from tkinter import ttk          
from Clases.Constructor import Aplicacion
from Clases.Constantes import *
from Clases.Funciones import *
from PIL import Image, ImageTk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

usuario_logeado = None

# --------------------- LOGIN ---------------------
def login(entry_usuario, entry_password, ventana_login, tipo_usuario):
    global usuario_logeado
    funcion = Funciones()
    
    correo = entry_usuario.get().strip()
    contrasena = entry_password.get().strip()
    
    if not correo or not contrasena:
        messagebox.showerror("Error", "Complete todos los campos")
        return

    password_hash = funcion.hash(contrasena)

    usuario_logeado = {
        "id": 1,
        "nombre": correo.split('@')[0].capitalize(),
        "correo": correo,
        "contrasena": password_hash,
        "tipo": tipo_usuario
    }
    
    ventana_login.destroy()
    
    if tipo_usuario == "cliente":
        menu_cliente()
    else:
        menu_empleado()


# --------------------- LOGIN CLIENTE ---------------------
def login_clientes(ventana_anterior):
    aplicacion = Aplicacion()
    ventana_anterior.withdraw()

    ventana_login = ctk.CTk()
    ventana_login.title("Login Clientes")
    ventana_login.geometry(SIZE_VENTANA)
    ventana_login.config(bg=NEGRO)

    aplicacion.crear_header(ventana_login, "Acceso Clientes")

    frame = ctk.CTkFrame(ventana_login, fg_color=NEGRO)
    frame.pack(expand=True)

    ctk.CTkLabel(frame, text="Correo:", font= ("Arial", 18, "bold"),text_color=BLANCO).pack(anchor="center", pady=(10, 3))
    entry_correo = ctk.CTkEntry(frame, width=300)
    entry_correo.pack(anchor="w", pady=(0, 10))

    ctk.CTkLabel(frame, text="Contraseña:", font= ("Arial", 18, "bold"),text_color=BLANCO).pack(anchor="center", pady=(10, 3))
    entry_contrasena = ctk.CTkEntry(frame, width=300, show="*")
    entry_contrasena.pack(anchor="w", pady=(0, 10))

    aplicacion.crear_boton(
        frame, "Iniciar Sesión",
        lambda: login(entry_correo, entry_contrasena, ventana_login, "cliente"),
        VERDE, BLANCO, width=200
    ).pack(pady=5)

    aplicacion.crear_boton(
        frame, "Volver",
        lambda: [ventana_login.destroy(), ventana_anterior.deiconify()],
        ROJO, BLANCO, width=200
    ).pack(pady=5)

    ventana_login.mainloop()


# --------------------- LOGIN EMPLEADO ---------------------
def login_empleados(ventana_anterior):
    aplicacion = Aplicacion()
    ventana_anterior.withdraw()

    ventana_login = ctk.CTk()
    ventana_login.title("Login Empleados")
    ventana_login.geometry(SIZE_VENTANA)
    ventana_login.config(bg=NEGRO)

    aplicacion.crear_header(ventana_login, "Acceso Empleados")
    
    frame = ctk.CTkFrame(ventana_login, fg_color=NEGRO)
    frame.pack(expand=True)

    ctk.CTkLabel(frame, text="Correo:", font= ("Arial", 18, "bold"), text_color=BLANCO).pack(anchor="center", pady=(10, 3))
    entry_correo = ctk.CTkEntry(frame, width=300)
    entry_correo.pack(anchor="w", pady=(0, 10))

    ctk.CTkLabel(frame, text="Contraseña:", font= ("Arial", 18, "bold"), text_color=BLANCO).pack(anchor="center", pady=(10, 3))
    entry_contrasena = ctk.CTkEntry(frame, width=300, show="*")
    entry_contrasena.pack(anchor="w", pady=(0, 10))

    aplicacion.crear_boton(
        frame, "Iniciar Sesión",
        lambda: login(entry_correo, entry_contrasena, ventana_login, "empleado"),
        VERDE, BLANCO, width=210, 
    ).pack(pady=5)

    aplicacion.crear_boton(
        frame, "Volver",
        lambda: [ventana_login.destroy(), ventana_anterior.deiconify()],
        ROJO, BLANCO, width=210
    ).pack(pady=5)

    ventana_login.mainloop()


# --------------------- INICIO ---------------------
def iniciar_sesion():
    ventana_inicio = ctk.CTk()
    ventana_inicio.title("Viajes Aventuras")
    ventana_inicio.geometry(SIZE_VENTANA)
    ventana_inicio.config(bg=NEGRO)
    aplicacion = Aplicacion(ventana_inicio)
    aplicacion.crear_header(ventana_inicio, "Viajes Aventura")

    imagen = Image.open("C:\\Users\karel\OneDrive\Escritorio\Viajes Aventuras entorno de Prueba\Assets\icon.png").resize((900,750))
    imagen_tk = ImageTk.PhotoImage(imagen)

    fondo_label = ctk.CTkLabel(
        ventana_inicio,
        image= imagen_tk,
        text="",
        fg_color=NEGRO
    )
    fondo_label.image = imagen_tk
    fondo_label.place(x=25, y=70, relwidth=1, relheight=1) 
    fondo_label.lower() 

    ctk.CTkLabel(
        ventana_inicio,
        text="Gestión de Reservas Turísticas",
        font=ctk.CTkFont("Arial", 26, "bold"),
        text_color=CELESTE
    ).pack(pady=(30, 80))

    frame_botones = ctk.CTkFrame(ventana_inicio, fg_color=NEGRO)
    frame_botones.pack(expand=True, anchor= "w", padx= 25)

    aplicacion.crear_boton(
        frame_botones, "Acceso Clientes",
        lambda: login_clientes(ventana_inicio),
        VERDE, BLANCO, width=210, height=50,
    ).pack(pady=20)

    aplicacion.crear_boton(
        frame_botones, "Acceso Empleados",
        lambda: login_empleados(ventana_inicio),
        AZUL, BLANCO, width=210, height=50,
    ).pack(pady=20)

    aplicacion.crear_boton(
        frame_botones, "Registrarse como Cliente",
        lambda: registrar_cliente(ventana_inicio),
        NARANJO, NEGRO, width=210, height=50,
    ).pack(pady=20)

    aplicacion.crear_boton(
        frame_botones, "Salir",
        lambda: ventana_inicio.destroy(),
        ROJO, BLANCO, width=210, height=50,
    ).pack(pady=20)

    ventana_inicio.mainloop()


# ---------------- MENÚS ----------------
def menu_cliente():

    aplicacion = Aplicacion()
    global usuario_logeado
    
    menu = ctk.CTk()
    menu.title("Menu de Cliente")
    menu.geometry(SIZE_VENTANA)
    menu.config(bg=NEGRO)
    #Recuperar la lista del dao
    aplicacion.crear_header(menu, f"Bienvenido {usuario_logeado['nombre']}")

    frame_tabla = ctk.CTkFrame(menu, fg_color=NEGRO, width= 600, height= 600)
    frame_tabla.place(x=625,y=255)

    frame = ctk.CTkFrame(menu, fg_color=NEGRO)
    frame.pack(pady=25, anchor= "w", expand=True)

    opciones = [
        "Destinos Disponibles",
        "Ver Paquetes",
        "Mis Reservas",
        "Mi Perfil"
    ]

    # TODO: si opcion == "Destinos Disponibles" o si opcion == "Ver Paquetes":

    def actualizar_tabla(opcion):

        for widget in frame_tabla.winfo_children():
            widget.destroy()
        
        if opcion == "Destinos Disponibles":
            columnas = ['id', 'nombre', 'pais', 'descripcion']

        elif opcion == "Ver Paquetes":
            columnas = ['id', 'nombre', 'precio', 'duracion']

        elif opcion == "Mis Reservas":
            columnas = ['id', 'fecha', 'destino', 'estado']

        elif opcion == "Mi Perfil":
            columnas = ['nombre', 'Email', 'Rut']
        
        aplicacion.tablas(frame_tabla, columnas, opcion)


    aplicacion.crear_boton(frame, "Hacer una Reserva", lambda: crear_reserva(menu), CELESTE).pack(anchor="w", pady=25)
    
    
    combo = ctk.CTkComboBox(
        frame, values=opciones,
        width=190, font=ctk.CTkFont("Arial", 14),
        command=lambda opcion: actualizar_tabla(opcion),
        fg_color=CELESTE, text_color=NEGRO, state='readonly'
    )    
    combo.set(opciones[0])
    combo.pack(pady=25, anchor="w")

    
    aplicacion.crear_boton(frame, "Cerrar Sesión", lambda: cerrar_sesion(menu), ROJO).pack(anchor="w", pady=25)
    actualizar_tabla(opciones[0])

    menu.mainloop()



def menu_empleado():
    aplicacion = Aplicacion()
    global usuario_logeado

    menu = ctk.CTk()
    menu.title("Menu de Empleados")
    menu.geometry(SIZE_VENTANA)

    aplicacion.crear_header(menu, f"Bienvenido {usuario_logeado['nombre']}")

    aplicacion.crear_boton(menu, "Gestión de Destinos", lambda: gestion_destinos(menu), CELESTE).pack(pady=5)
    aplicacion.crear_boton(menu, "Gestión de Paquetes", lambda: gestion_paquetes(menu), AZUL, BLANCO).pack(pady=5)
    aplicacion.crear_boton(menu, "Cerrar Sesión", lambda: cerrar_sesion(menu), ROJO, BLANCO_CLARO).pack(pady=5)

    menu.mainloop()


# ---------------- UTILIDADES ----------------
def cerrar_sesion(ventana):
    global usuario_logeado
    usuario_logeado = None
    ventana.destroy()
    iniciar_sesion()


def ventana_destinos(ventana_padre):
    messagebox.showinfo("Info", "En Progreso")

def ventana_paquetes(ventana_padre):
    messagebox.showinfo("Info", "En Progreso")

def ventana_reservas(ventana_padre):
    messagebox.showinfo("Info", "En Progreso")

def crear_reserva(ventana_padre):
    messagebox.showinfo("Nueva Reserva", "En Desarrollo")

def gestion_destinos(ventana_padre):
    messagebox.showinfo("Info", "En Proceso")

def gestion_paquetes(ventana_padre):
    messagebox.showinfo("Info", "En Proceso")

def registrar_cliente(ventana_padre):
    messagebox.showinfo("Info", "En Progreso")


if __name__ == "__main__":
    iniciar_sesion()
