import hashlib
import customtkinter as ctk
from tkinter import ttk   
from Clases.Constantes import *
from Clases.Funciones import *
import os

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class Aplicacion:
    def __init__(self, ventana=None):
        if ventana:
            self.ventana = ventana
        else:
            pass
    # ---------------------- HEADER ----------------------
    def crear_header(self, ventana, texto, font_size=35):

        header = ctk.CTkFrame(ventana, height=80, fg_color=AZUL)
        header.pack(fill="x")

        ctk.CTkLabel(
            header,
            text=texto,
            font=ctk.CTkFont("Arial", font_size, "bold"),
            text_color=BLANCO
        ).pack(pady=20)

        return header

    # ---------------------- BOTONES ----------------------
    def crear_boton(self, padre, texto, comando, color=CELESTE, fg=None, **kwargs, ):

        if fg is None:
            fg = BLANCO if color == ROJO else NEGRO

        por_defecto = {
            "font": ctk.CTkFont("Arial", 15, "bold"),
            "fg_color": color,
            "text_color": fg,
            "width": 180,
            "corner_radius":25,
            "height": 40,
            "hover_color": HOVER,

        }
        por_defecto.update(kwargs)

        
        return ctk.CTkButton(padre, text=texto, command=comando, **por_defecto)

    # ---------------------- ENTRADAS ----------------------
    def crear_entradas(self, padre, texto, campos_dict, key,
                       tipo="entry", valores=None, show=None, width=240):

        ctk.CTkLabel(
            padre,
            text=f"{texto}:",
            text_color=BLANCO,
            font=ctk.CTkFont("Arial", 12, "bold"),
        ).pack(anchor="w", pady=(10, 3))

        if tipo == "entry":
            campo = ctk.CTkEntry(
                padre,
                font=ctk.CTkFont("Arial", 12, "bold"),
                width=width,
                show=show,
            )

        elif tipo == "combo":
            campo = ctk.CTkComboBox(
                padre,
                font=ctk.CTkFont("Arial", 12, "bold"),
                values=valores if valores else [],
                width=width
            )
            if valores:
                campo.set(valores[0])

        campo.pack(anchor="w", pady=(0, 10))
        campos_dict[key] = campo
        return campo

    # ---------------------- TABLA ----------------------
    def tablas(self, padre, columnas, titulo="Tabla"):

        tablas_frame = ctk.CTkFrame(padre, fg_color=NEGRO)
        tablas_frame.pack(side="right", fill="both", expand=True)

        ctk.CTkLabel(
            tablas_frame,
            text=titulo,
            font=ctk.CTkFont("Arial", 14, "bold"),
            text_color=BLANCO
        ).pack(anchor="w", pady=10)

        # Treeview sigue siendo ttk
        tabla = ttk.Treeview(tablas_frame, columns=columnas, show="headings", height=20)

        ancho = {
            "ID": 50, "Nombre": 180, "Descripcion": 250, "Precio": 100,
            "Fecha": 100, "Estado": 75, "Pais": 100, "Cupos": 80, "Paquete": 180
        }

        for columna in columnas:
            tabla.heading(columna, text=columna)
            width = ancho.get(columna, 150)
            tabla.column(columna, width=width, anchor="center")

        tabla.pack(fill="both", expand=True)
        return tabla

    # ---------------------- CREAR VENTANA ----------------------
    def crear_ventana(self, ventana_padre, titulo, columnas_tabla, titulo_tabla, botones_config):

        funcion = Funciones()
        ventana_padre.withdraw()

        ventana = ctk.CTkToplevel()
        ventana.title(titulo)
        ventana.geometry(SIZE_VENTANA)

        contenido = ctk.CTkFrame(ventana, fg_color=NEGRO)
        contenido.pack(fill="both", expand=True, padx=20, pady=20)

        # Panel lateral de botones
        panel_botones = ctk.CTkFrame(contenido, fg_color=NEGRO)
        panel_botones.pack(side="left", fill="y", padx=(0, 10))

        # Crear botones
        for texto, comando, color in botones_config:
            fg = BLANCO if color == ROJO else None
            self.crear_boton(panel_botones, texto, comando, color, fg).pack(pady=5)

        # Crear tabla
        tabla = self.tablas(contenido, columnas_tabla, titulo_tabla)

        # Botón inferior
        self.crear_boton(
            ventana,
            "Volver Atrás",
            lambda: funcion.volver_menu(ventana, ventana_padre),
            color=ROJO,
            fg=BLANCO_CLARO,
            width=200,
            height=40
        ).pack(pady=20)

        return ventana, tabla
