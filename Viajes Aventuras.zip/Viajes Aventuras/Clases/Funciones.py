import hashlib
import tkinter as tk
from tkinter import *

class Funciones:
    def __init__(self, ventana=None):
        if ventana:
            self.ventana = ventana
        else: 
            pass
    def hash(self, password):
        return hashlib.sha256(password.encode()).hexdigest()


    def volver_menu(ventana_actual, ventana_anterior):

        ventana_actual.destroy()
        ventana_anterior.deiconify()

    def cargar_datos_tabla(tabla, tipo):
        pass