import tkinter as tk
import re

from tkinter import messagebox

#validaciones

def campos_obligatorios(campos, obligatorio):

    for nombre, campo in obligatorio.items():
        valor = campo.get().strip()

        if not valor:

            messagebox.showerror("Error","Complete los campos obligatorios")
            return False
        
    return True

def validar_correo(correo):
    if not correo or not correo.strip():
        return False
    patron = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

    if not re.match(patron, correo.strip()):
        return False
    
    return True
